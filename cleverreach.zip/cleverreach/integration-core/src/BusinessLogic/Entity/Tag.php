<?php

namespace CleverReach\BusinessLogic\Entity;

class Tag extends AbstractTag
{
    /**
     * @inheritdoc
     */
    public function __construct($name, $type)
    {
        parent::__construct($name, $type);
    }
}
