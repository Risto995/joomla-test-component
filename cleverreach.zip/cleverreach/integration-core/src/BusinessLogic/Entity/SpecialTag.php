<?php

namespace CleverReach\BusinessLogic\Entity;

class SpecialTag extends AbstractTag
{
    /**
     * SpecialTag constructor.
     *
     * @param string $name Valid special tag name. Use constants in this class for valid names.
     */
    protected function __construct($name)
    {
        parent::__construct($name, 'Special');
    }

    /**
     * Returns new special tag "Customer"
     *
     * @return \CleverReach\BusinessLogic\Entity\SpecialTag
     */
    public static function customer()
    {
        return new SpecialTag('Customer');
    }

    /**
     * Returns new special tag "Subscriber"
     *
     * @return \CleverReach\BusinessLogic\Entity\SpecialTag
     */
    public static function subscriber()
    {
        return new SpecialTag('Subscriber');
    }

    /**
     * Returns new special tag "Buyer"
     *
     * @return \CleverReach\BusinessLogic\Entity\SpecialTag
     */
    public static function buyer()
    {
        return new SpecialTag('Buyer');
    }

    /**
     * Returns new special tag "Contact"
     *
     * @return \CleverReach\BusinessLogic\Entity\SpecialTag
     */
    public static function contact()
    {
        return new SpecialTag('Contact');
    }

    /**
     * Gets collection of all valid special tags.
     *
     * @return \CleverReach\BusinessLogic\Entity\SpecialTagCollection
     */
    public static function all()
    {
        $result = new SpecialTagCollection();
        $result->addTag(self::customer())
            ->addTag(self::subscriber())
            ->addTag(self::buyer())
            ->addTag(self::contact());

        return $result;
    }
}
