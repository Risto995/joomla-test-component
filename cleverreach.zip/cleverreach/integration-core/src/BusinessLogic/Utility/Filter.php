<?php

namespace CleverReach\BusinessLogic\Utility;

/**
 * Class Filter
 *
 * @package CleverReach\BusinessLogic\Utility
 */
class Filter
{
    const CLASS_NAME = __CLASS__;

    /**
     * @var  int
     */
    private $id;
    /**
     * @var  string
     */
    private $name;

    /**
     * @var  string
     */
    private $operator;

    /**
     * @var Rule[]
     */
    private $allRules = array();

    /**
     * Filter constructor.
     *
     * @param string $name
     * @param Rule $rule
     * @param string $operator
     */
    public function __construct($name, Rule $rule, $operator = null)
    {
        $this->name = $name;

        $this->operator = $operator ?: 'AND';

        $this->allRules[] = $rule;
    }

    /**
     * @return array
     */
    public function toArray()
    {
        return array(
            'name' => $this->name,
            'operator' => $this->operator,
            'rules' => $this->rulesToArray()
        );
    }

    /**
     * Get allRules
     *
     * @return Rule[]
     */
    public function getAllRules()
    {
        return $this->allRules;
    }

    /**
     * @param Rule[] $allRules
     */
    public function setAllRules($allRules)
    {
        $this->allRules = $allRules;
    }

    /**
     * @return int
     */
    public function getId()
    {
        return $this->id;
    }

    /**
     * @param int $id
     */
    public function setId($id)
    {
        $this->id = $id;
    }

    /**
     * @return string
     */
    public function getName()
    {
        return $this->name;
    }

    /**
     * @param string $name
     */
    public function setName($name)
    {
        $this->name = $name;
    }

    /**
     * @return mixed
     */
    public function getFirstCondition()
    {
        return $this->allRules[0]->getCondition();
    }

    /**
     * @param Rule $rule
     */
    public function addRule(Rule $rule)
    {
        $this->allRules[] = $rule;
    }

    /**
     * Converts allRules[Rule] to allRules[array[]]
     *
     * @return array[array]
     */
    private function rulesToArray()
    {
        $ret = array();
        foreach ($this->allRules as $rule) {
            $ret[] = $rule->toArray();
        }

        return $ret;
    }
}
