<?php

namespace CleverReach\BusinessLogic\Utility\ArticleSearch\SearchResult;

/**
 * Class TextAttribute, text type of attribute for search result
 * @package CleverReach\BusinessLogic\Utility\ArticleSearch\SearchResult
 */
class TextAttribute extends SimpleAttribute
{

}
