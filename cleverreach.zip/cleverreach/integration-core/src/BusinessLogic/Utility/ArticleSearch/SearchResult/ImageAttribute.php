<?php

namespace CleverReach\BusinessLogic\Utility\ArticleSearch\SearchResult;


/**
 * Class ImageAttribute, image attribute for search result
 * @package CleverReach\BusinessLogic\Utility\ArticleSearch\SearchResult
 */
class ImageAttribute extends SimpleAttribute
{

}
