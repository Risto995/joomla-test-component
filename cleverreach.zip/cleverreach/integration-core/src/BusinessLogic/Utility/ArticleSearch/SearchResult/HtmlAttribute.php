<?php

namespace CleverReach\BusinessLogic\Utility\ArticleSearch\SearchResult;


/**
 * Class HtmlAttribute, html attribute for search result
 * @package CleverReach\BusinessLogic\Utility\ArticleSearch\SearchResult
 */
class HtmlAttribute extends SimpleAttribute
{

}
