<?php

namespace CleverReach\BusinessLogic\Utility\ArticleSearch\Exceptions;

/**
 * Class InvalidSchemaMatching
 *
 * @package CleverReach\BusinessLogic\Utility\ArticleSearch\Exceptions
 */
class InvalidSchemaMatching extends \Exception
{

}