<?php

namespace CleverReach\BusinessLogic\Sync;

use CleverReach\Infrastructure\Exceptions\InvalidConfigurationException;
use CleverReach\Infrastructure\Utility\Exceptions\HttpAuthenticationException;
use CleverReach\Infrastructure\Utility\Exceptions\HttpCommunicationException;
use CleverReach\Infrastructure\Utility\Exceptions\HttpRequestException;

/**
 * Class GroupSyncTask
 *
 * @package CleverReach\BusinessLogic\Sync
 */
class GroupSyncTask extends BaseSyncTask
{
    /**
     * Runs task logic
     *
     * @throws InvalidConfigurationException
     * @throws HttpAuthenticationException
     * @throws HttpCommunicationException
     * @throws HttpRequestException
     */
    public function execute()
    {
        /** @var string $serviceName */
        $serviceName = $this->getConfigService()->getIntegrationListName();

        $this->reportAlive();
        $this->validateServiceName($serviceName);
        $this->reportProgress(50);

        $groupId = $this->getProxy()->getGroupId($serviceName);

        if ($groupId === null) {
            $this->reportProgress(75);
            $newGroupId = $this->getProxy()->createGroup($serviceName);
            $this->getConfigService()->setIntegrationId($newGroupId);
        } else {
            $this->getConfigService()->setIntegrationId($groupId);
        }

        $this->reportProgress(100);
    }

    /**
     * Validates if $serviceName parameter is set
     *
     * @param string $serviceName
     *
     * @throws InvalidConfigurationException
     */
    private function validateServiceName($serviceName)
    {
        if (empty($serviceName)) {
            throw new InvalidConfigurationException('Integration name not set in Configuration Service');
        }
    }
}
