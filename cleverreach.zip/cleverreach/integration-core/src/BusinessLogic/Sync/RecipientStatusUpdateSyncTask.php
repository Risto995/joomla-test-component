<?php

namespace CleverReach\BusinessLogic\Sync;

/**
 * Class RecipientStatusUpdateSyncTask
 *
 * @package CleverReach\BusinessLogic\Sync
 */
abstract class RecipientStatusUpdateSyncTask extends BaseSyncTask
{
    /**
     * @var array
     */
    public $recipientEmails;

    /**
     * RecipientStatusUpdateSyncTask constructor.
     *
     * @param array $recipientEmails
     */
    public function __construct(array $recipientEmails)
    {
        $this->recipientEmails = $recipientEmails;
    }

    /**
     * @return string
     */
    public function serialize()
    {
        return serialize($this->recipientEmails);
    }

    /**
     * @param string $serialized
     */
    public function unserialize($serialized)
    {
        $this->recipientEmails = unserialize($serialized);
    }
}
