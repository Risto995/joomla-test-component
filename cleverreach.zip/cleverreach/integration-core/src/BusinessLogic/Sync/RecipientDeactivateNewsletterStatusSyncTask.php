<?php

namespace CleverReach\BusinessLogic\Sync;

use CleverReach\Infrastructure\Utility\Exceptions\HttpAuthenticationException;
use CleverReach\Infrastructure\Utility\Exceptions\HttpCommunicationException;
use CleverReach\Infrastructure\Utility\Exceptions\HttpRequestException;

/**
 * Class RecipientDeactivateNewsletterStatusSyncTask
 *
 * @package CleverReach\BusinessLogic\Sync
 */
class RecipientDeactivateNewsletterStatusSyncTask extends RecipientStatusUpdateSyncTask
{
    /**
     * Runs task logic
     *
     * @throws HttpAuthenticationException
     * @throws HttpCommunicationException
     * @throws HttpRequestException
     */
    public function execute()
    {
        $this->getProxy()->updateNewsletterStatus($this->recipientEmails);
        $this->reportProgress(100);
    }
}
