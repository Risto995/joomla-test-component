<?php

namespace CleverReach\BusinessLogic\Interfaces;

/**
 * Interface Proxy
 *
 * @package CleverReach\BusinessLogic\Interfaces
 */
interface Proxy
{
    const CLASS_NAME = __CLASS__;

    /**
     * Call http client
     *
     * @param string $method
     * @param string $endpoint
     * @param array $body
     * @param string $accessToken
     *
     * @return array
     */
    public function call($method, $endpoint, $body = array(), $accessToken = '');
}
