<?php

namespace CleverReach\Infrastructure\Utility;

/**
 * Class GuidProvider
 *
 * @package CleverReach\Infrastructure\Utility
 */
class GuidProvider
{
    const CLASS_NAME = __CLASS__;

    /**
     * @return string
     */
    public function generateGuid()
    {
        return uniqid(getmypid().'_');
    }
}
