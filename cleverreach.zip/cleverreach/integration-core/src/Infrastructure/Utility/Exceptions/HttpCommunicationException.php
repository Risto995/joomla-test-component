<?php

namespace CleverReach\Infrastructure\Utility\Exceptions;

use Exception;

/**
 * Class HttpCommunicationException
 *
 * @package CleverReach\Infrastructure\Utility\Exceptions
 */
class HttpCommunicationException extends Exception
{
    
}
