<?php

namespace CleverReach\Infrastructure\Utility\Exceptions;

use Exception;

/**
 * Class HttpRequestException
 *
 * @package CleverReach\Infrastructure\Utility\Exceptions
 */
class HttpRequestException extends Exception
{
    
}
