<?php

namespace CleverReach\Infrastructure\Utility\Exceptions;

use Exception;

/**
 * Class HttpBatchSizeTooBigException
 *
 * @package CleverReach\Infrastructure\Utility\Exceptions
 */
class HttpBatchSizeTooBigException extends Exception
{

}
