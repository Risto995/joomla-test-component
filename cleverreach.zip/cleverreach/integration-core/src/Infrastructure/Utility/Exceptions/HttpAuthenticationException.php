<?php

namespace CleverReach\Infrastructure\Utility\Exceptions;

use Exception;

/**
 * Class HttpAuthenticationException
 *
 * @package CleverReach\Infrastructure\Utility\Exceptions
 */
class HttpAuthenticationException extends Exception
{
    
}
