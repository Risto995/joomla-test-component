<?php

namespace CleverReach\Infrastructure\Utility\Exceptions;

use Exception;

/**
 * Class HttpUnhandledException
 *
 * @package CleverReach\Infrastructure\Utility\Exceptions
 */
class HttpUnhandledException extends Exception
{

}
