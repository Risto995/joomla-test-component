<?php

namespace CleverReach\Infrastructure\Interfaces\Required;

use CleverReach\Infrastructure\Logger\Logger;
use CleverReach\Infrastructure\ServiceRegister;
use CleverReach\Infrastructure\TaskExecution\Exceptions\TaskRunnerStatusStorageUnavailableException;

/**
 * Class Configuration
 *
 * @package CleverReach\Infrastructure\Interfaces\Required
 */
abstract class Configuration
{

    const CLASS_NAME = __CLASS__;

    const INITIAL_BATCH_SIZE = 250;
    const DEFAULT_MAX_STARTED_TASK_LIMIT = 16;
    const DEFAULT_CLEVERREACH_ASYNC_REQUEST_TIMEOUT = 1000;

    /**
     * @var ConfigRepositoryInterface
     */
    protected $configRepository;
    /**
     * @var  string
     */
    protected $accessToken;
    /**
     * @var  array
     */
    protected $userInfo;
    /**
     * @var string
     */
    protected static $context;

    /**
     * Sets task execution context.
     *
     * When integration supports multiple accounts (middleware integration) proper context must be set based on middleware account
     * that is using core library functionality. This context should then be used by business services to fetch account specific
     * data.Core will set context provided upon task enqueueing before task execution.
     *
     * @param string $context Context to set
     */
    public function setContext($context)
    {
        self::$context = $context;
    }

    /**
     * Gets task execution context
     *
     * @return string Context in which task is being executed. If no context is provided empty string is returned (global context)
     */
    public function getContext()
    {
        if (!empty(self::$context)) {
            return self::$context;
        }

        return '';
    }

    /**
     * Saves min log level in integration database
     *
     * @param int $minLogLevel
     */
    public function saveMinLogLevel($minLogLevel)
    {
        $this->getConfigRepository()->set('CLEVERREACH_MIN_LOG_LEVEL', $minLogLevel);
    }

    /**
     * Retrieves min log level from integration database
     *
     * @return int
     */
    public function getMinLogLevel()
    {
        return (int)$this->getConfigRepository()->get('CLEVERREACH_MIN_LOG_LEVEL') ?: Logger::WARNING;
    }

    /**
     * Retrieves access token from integration database
     *
     * @return string | null
     */
    public function getAccessToken()
    {
        if (empty($this->accessToken)) {
            $this->accessToken = $this->getConfigRepository()->get('CLEVERREACH_ACCESS_TOKEN');
        }

        return $this->accessToken;
    }

    /**
     * Return whether product search is enabled or not
     *
     * @return bool
     */
    public function isProductSearchEnabled()
    {
        return false;
    }

    /**
     * Retrieves parameters needed for product search registrations
     *
     * @return array, with array keys name, url, password
     */
    public function getProductSearchParameters()
    {
        return array();
    }

    /**
     * Retrieves integration id
     *
     * @return int | null
     */
    public function getIntegrationId()
    {
        return $this->getConfigRepository()->get('CLEVERREACH_INTEGRATION_ID');
    }

    /**
     * Retrieves user account id
     *
     * @return string
     */
    public function getUserAccountId()
    {
        $userInfo = $this->getUserInfo();

        return !empty($userInfo['id']) ? $userInfo['id'] : '';
    }

    /**
     * Set default logger status (enabled/disabled)
     *
     * @param bool $status
     */
    public function setDefaultLoggerEnabled($status)
    {
        $this->getConfigRepository()->set('CLEVERREACH_DEFAULT_LOGGER_STATUS', $status);
    }

    /**
     * Return whether default logger is enabled or not
     *
     * @return bool
     */
    public function isDefaultLoggerEnabled()
    {
        $defaultLoggerStatus = (int)$this->getConfigRepository()->get('CLEVERREACH_DEFAULT_LOGGER_STATUS');

        return ($defaultLoggerStatus === 1);
    }

    /**
     * Gets the number of maximum allowed started task at the point in time.
     * This number will determine how many tasks can be in "in_progress" status at the same time.
     *
     * @return int
     */
    public function getMaxStartedTasksLimit()
    {
        return (int)$this->getConfigRepository()->get('CLEVERREACH_MAX_STARTED_TASK_LIMIT')
            ?: self::DEFAULT_MAX_STARTED_TASK_LIMIT;
    }

    /**
     * @param int $maxStartedTaskLimit
     */
    public function setMaxStartedTaskLimit($maxStartedTaskLimit)
    {
        $this->getConfigRepository()->set('CLEVERREACH_MAX_STARTED_TASK_LIMIT', $maxStartedTaskLimit);
    }

    /**
     * Get user information
     *
     * @return array | null
     */
    public function getUserInfo()
    {
        if (empty($this->userInfo)) {
            $this->userInfo = json_decode($this->getConfigRepository()->get('CLEVERREACH_USER_INFO'), true);
        }

        return $this->userInfo;
    }

    /**
     * Return if first email is already built
     *
     * @return bool
     */
    public function isFirstEmailBuilt()
    {
        $firstEmailBuild = (int)$this->getConfigRepository()->get('CLEVERREACH_FIRST_EMAIL_BUILD');

        return $firstEmailBuild === 1;
    }

    /**
     * Set if first email is built
     *
     * @param $value
     */
    public function setIsFirstEmailBuilt($value)
    {
        $this->getConfigRepository()->set('CLEVERREACH_FIRST_EMAIL_BUILD', $value);
    }

    /**
     * Saves created groupId in CR to integration
     *
     * @param int $id
     */
    public function setIntegrationId($id)
    {
        $this->getConfigRepository()->set('CLEVERREACH_INTEGRATION_ID', $id);
    }

    /**
     * Automatic task runner wakeup delay in seconds.
     * Task runner will sleep at the end of its lifecycle for this value seconds
     * before it sends wakeup signal for a new lifecycle. Return null to use default system value (10)
     *
     * @return int|null
     */
    public function getTaskRunnerWakeupDelay()
    {
        return (int)$this->getConfigRepository()->get('CLEVERREACH_TASK_RUNNER_WAKEUP_DELAY') ?: null;
    }

    /**
     * @param int $taskRunnerWakeUpDelay
     */
    public function setTaskRunnerWakeUpDelay($taskRunnerWakeUpDelay)
    {
        $this->getConfigRepository()->set('CLEVERREACH_TASK_RUNNER_WAKEUP_DELAY', $taskRunnerWakeUpDelay);
    }

    /**
     * Gets maximal time in seconds allowed for runner instance to stay in alive (running) status.
     * After this period system will automatically start new runner instance and shutdown old one.
     * Return null to use default system value (60).
     *
     * @return int|null
     */
    public function getTaskRunnerMaxAliveTime()
    {
        return (int)$this->getConfigRepository()->get('CLEVERREACH_MAX_ALIVE_TIME') ?: null;
    }

    /**
     * @param int $taskRunnerMaxAliveTime
     */
    public function setTaskRunnerMaxAliveTime($taskRunnerMaxAliveTime)
    {
        $this->getConfigRepository()->set('CLEVERREACH_MAX_ALIVE_TIME', $taskRunnerMaxAliveTime);
    }

    /**
     * Gets maximum number of failed task execution retries.
     * System will retry task execution in case of error until this number is reached.
     * Return null to use default system value (5).
     *
     * @return int|null
     */
    public function getMaxTaskExecutionRetries()
    {
        return (int)$this->getConfigRepository()->get('CLEVERREACH_MAX_TASK_EXECUTION_RETRIES') ?: null;
    }

    /**
     * @param int $maxTaskExecutionRetries
     */
    public function setMaxTaskExecutionRetries($maxTaskExecutionRetries)
    {
        $this->getConfigRepository()->set('CLEVERREACH_MAX_TASK_EXECUTION_RETRIES', $maxTaskExecutionRetries);
    }

    /**
     * Gets max inactivity period for a task in seconds.
     * After inactivity period is passed, system will fail such tasks as expired.
     * Return null to use default system value (30).
     *
     * @return int|null
     */
    public function getMaxTaskInactivityPeriod()
    {
        return (int)$this->getConfigRepository()->get('CLEVERREACH_MAX_TASK_INACTIVITY_PERIOD') ?: null;
    }

    /**
     * @param int $maxTaskInactivityPeriod
     */
    public function setMaxTaskInactivityPeriod($maxTaskInactivityPeriod)
    {
        $this->getConfigRepository()->set('CLEVERREACH_MAX_TASK_INACTIVITY_PERIOD', $maxTaskInactivityPeriod);
    }

    public function getTaskRunnerStatus()
    {
        return json_decode($this->getConfigRepository()->get('CLEVERREACH_TASK_RUNNER_STATUS'), true);
    }

    /**
     * Sets task runner status information as JSON encoded string.
     *
     * @param string $guid
     * @param int $timestamp
     *
     * @throws TaskRunnerStatusStorageUnavailableException
     */
    public function setTaskRunnerStatus($guid, $timestamp)
    {
        $taskRunnerStatus = json_encode(array('guid' => $guid, 'timestamp' => $timestamp));
        $response = $this->getConfigRepository()->set('CLEVERREACH_TASK_RUNNER_STATUS', $taskRunnerStatus);

        if (empty($response)) {
            throw new TaskRunnerStatusStorageUnavailableException('Task runner status storage is not available.');
        }
    }

    /**
     * Save access token in integration database
     *
     * @param string $accessToken
     */
    public function setAccessToken($accessToken)
    {
        $this->getConfigRepository()->set('CLEVERREACH_ACCESS_TOKEN', $accessToken);
        $this->accessToken = $accessToken;
    }

    /**
     * @param array $userInfo
     */
    public function setUserInfo($userInfo)
    {
        $this->getConfigRepository()->set('CLEVERREACH_USER_INFO', json_encode($userInfo));
        $this->userInfo = $userInfo;
    }

    /**
     * @return int|string
     */
    public function getProductSearchEndpointPassword()
    {
        return $this->getConfigRepository()->get('CLEVERREACH_PRODUCT_SEARCH_PASSWORD');
    }

    /**
     * @param string $password
     */
    public function setProductSearchEndpointPassword($password)
    {
        $this->getConfigRepository()->set('CLEVERREACH_PRODUCT_SEARCH_PASSWORD', $password);
    }

    /**
     * @return string
     */
    public function getQueueName()
    {
        return $this->getContext() . ' - Default';
    }

    /**
     * Gets batch size for synchronization set in configuration.
     *
     * @return int
     */
    public function getRecipientsSynchronizationBatchSize()
    {
        return (int)$this->getConfigRepository()->get('CLEVERREACH_RECIPIENT_SYNC_BATCH_SIZE') ?:
        self::INITIAL_BATCH_SIZE;
    }

    /**
     * Sets synchronization batch size.
     *
     * @param int $batchSize
     *
     * @return int | null
     */
    public function setRecipientsSynchronizationBatchSize($batchSize)
    {
        return $this->getConfigRepository()->set('CLEVERREACH_RECIPIENT_SYNC_BATCH_SIZE', $batchSize);
    }

    /**
     * @param string $params
     *
     * @return bool|int
     */
    public function setCleverReachFailedLoginMessageParams($params)
    {
        return $this->getConfigRepository()->set('CLEVERREACH_FAILED_LOGIN_MESSAGE_PARAMS', $params);
    }

    /**
     * @return int|string
     */
    public function getCleverReachFailedLoginMessageParams()
    {
        return $this->getConfigRepository()->get('CLEVERREACH_FAILED_LOGIN_MESSAGE_PARAMS');
    }

    /**
     * Returns async process request timeout
     *
     * @return int
     */
    public function getAsyncProcessRequestTimeout()
    {
        return (int)$this->getConfigRepository()->get('CLEVERREACH_ASYNC_REQUEST_TIMEOUT')
            ?: self::DEFAULT_CLEVERREACH_ASYNC_REQUEST_TIMEOUT;
    }

    /**
     * Saves async process request timeout
     *
     * @param int $value
     */
    public function setAsyncProcessRequestTimeout($value)
    {
        $this->getConfigRepository()->set('CLEVERREACH_ASYNC_REQUEST_TIMEOUT', $value);
    }

    /**
     * @return string
     */
    public function getIntegrationListName()
    {
        return $this->getIntegrationName();
    }

    /**
     * Retrieves integration name
     *
     * @return string
     */
    abstract public function getIntegrationName();

    /**
     * @return string
     */
    abstract public function getClientId();

    /**
     * @return string
     */
    abstract public function getClientSecret();

    /**
     * @return ConfigRepositoryInterface
     */
    protected function getConfigRepository()
    {
        if ($this->configRepository === null) {
            $this->configRepository = ServiceRegister::getService(ConfigRepositoryInterface::CLASS_NAME);
        }

        return $this->configRepository;
    }
}
