<?php

namespace CleverReach\Infrastructure\Interfaces\Required;

interface ConfigRepositoryInterface
{
    const CLASS_NAME = __CLASS__;

    /**
     * @param string $key
     *
     * @return string | int
     */
    public function get($key);

    /**
     * @param string $key
     * @param mixed $value
     *
     * @return int | bool
     */
    public function set($key, $value);
}