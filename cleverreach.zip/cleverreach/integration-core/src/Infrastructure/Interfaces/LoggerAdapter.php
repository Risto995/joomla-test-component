<?php

namespace CleverReach\Infrastructure\Interfaces;

use CleverReach\Infrastructure\Logger\LogData;

/**
 * Interface LoggerAdapter
 *
 * @package CleverReach\Infrastructure\Interfaces
 */
interface LoggerAdapter
{
    /**
     * Log message in system
     *
     * @param LogData $data
     */
    public function logMessage($data);
}
