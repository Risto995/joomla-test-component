<?php

namespace CleverReach\Infrastructure\TaskExecution\Exceptions;

/**
 * Class RecipientsGetException
 *
 * @package CleverReach\Infrastructure\TaskExecution\Exceptions
 */
class RecipientsGetException extends \Exception
{

}
