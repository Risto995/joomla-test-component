<?php

namespace CleverReach\Infrastructure\TaskExecution\Exceptions;

/**
 * Class SyncTaskFailedException
 *
 * @package CleverReach\Infrastructure\TaskExecution\Exceptions
 */
class SyncTaskFailedException extends \Exception
{

}
