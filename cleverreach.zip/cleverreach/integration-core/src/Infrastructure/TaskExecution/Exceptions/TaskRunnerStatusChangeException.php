<?php

namespace CleverReach\Infrastructure\TaskExecution\Exceptions;

/**
 * Class TaskRunnerStatusChangeException
 *
 * @package CleverReach\Infrastructure\TaskExecution\Exceptions
 */
class TaskRunnerStatusChangeException extends \Exception
{
}
