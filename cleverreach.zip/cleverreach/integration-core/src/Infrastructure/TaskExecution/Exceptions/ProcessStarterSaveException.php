<?php

namespace CleverReach\Infrastructure\TaskExecution\Exceptions;

/**
 * Class ProcessStarterSaveException
 *
 * @package CleverReach\Infrastructure\TaskExecution\Exceptions
 */
class ProcessStarterSaveException extends \Exception
{

}
