<?php

namespace CleverReach\Infrastructure\TaskExecution\Exceptions;

/**
 * Class QueueItemDeserializationException
 *
 * @package CleverReach\Infrastructure\TaskExecution\Exceptions
 */
class QueueItemDeserializationException extends \Exception
{
}
