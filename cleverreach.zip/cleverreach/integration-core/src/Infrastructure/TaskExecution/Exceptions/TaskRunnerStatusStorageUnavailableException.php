<?php

namespace CleverReach\Infrastructure\TaskExecution\Exceptions;

/**
 * Class TaskRunnerStatusStorageUnavailableException
 *
 * @package CleverReach\Infrastructure\TaskExecution\Exceptions
 */
class TaskRunnerStatusStorageUnavailableException extends \Exception
{
}
