<?php

namespace CleverReach\Infrastructure\TaskExecution\Exceptions;

/**
 * Class QueueStorageUnavailableException
 *
 * @package CleverReach\Infrastructure\TaskExecution\Exceptions
 */
class QueueStorageUnavailableException extends \Exception
{
}
