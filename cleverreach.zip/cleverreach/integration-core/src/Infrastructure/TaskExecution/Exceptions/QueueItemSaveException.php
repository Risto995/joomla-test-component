<?php

namespace CleverReach\Infrastructure\TaskExecution\Exceptions;

/**
 * Class QueueItemSaveException
 *
 * @package CleverReach\Infrastructure\TaskExecution\Exceptions
 */
class QueueItemSaveException extends \Exception
{
}
