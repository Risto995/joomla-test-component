<?php

namespace CleverReach\Infrastructure\TaskExecution\Exceptions;

/**
 * Class TaskRunnerRunException
 *
 * @package CleverReach\Infrastructure\TaskExecution\Exceptions
 */
class TaskRunnerRunException extends \Exception
{
}
