<?php

namespace CleverReach\Infrastructure\TaskExecution\Exceptions;

/**
 * Class ProcessStorageGetException
 *
 * @package CleverReach\Infrastructure\TaskExecution\Exceptions
 */
class ProcessStorageGetException extends \Exception
{

}
