<?php
namespace CleverReach\Infrastructure\Exceptions;

use Exception;

/**
 * Class InvalidConfigurationException
 *
 * @package CleverReach\Infrastructure\Exceptions
 */
class InvalidConfigurationException extends Exception
{

}
