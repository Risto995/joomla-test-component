<?php

namespace CleverReach\Tests\BusinessLogic\Sync;

use CleverReach\BusinessLogic\Sync\RefreshUserInfoTask;
use CleverReach\Infrastructure\TaskExecution\TaskEvents\ProgressedTaskEvent;
use CleverReach\Infrastructure\Utility\Exceptions\HttpRequestException;

class RefreshUserInfoTaskTest extends BaseSyncTest
{
    /**
     * Run test when GetUserInfo returns valid info
     */
    public function testGetUserInfoReturnsValidInfo()
    {
        $this->syncTask->execute();
        $accessToken = $this->shopConfig->getAccessToken();

        $this->assertNotEmpty($accessToken, 'Method should set access token in configuration service.');
        $this->assertNotEmpty($this->eventHistory, 'History of fired report progress events must not be empty.');
        /** @var ProgressedTaskEvent $lastReportProgress */
        $lastReportProgress = end($this->eventHistory);
        $this->assertEquals(100, $lastReportProgress->getProgressFormatted(), 'Last report progress must be set with 100%.');
    }

    /**
     * Run test when GetUserInfo returns empty array
     */
    public function testGetUserInfoReturnsEmptyArray()
    {
        $this->proxy->setResponse('{}');
        $this->syncTask->execute();
        $accessToken = $this->shopConfig->getAccessToken();

        $this->assertEmpty($accessToken, 'Method should clear access token in configuration service.');
        $this->assertNotEmpty($this->eventHistory, 'History of fired report progress events must not be empty.');
        /** @var ProgressedTaskEvent $lastReportProgress */
        $lastReportProgress = end($this->eventHistory);
        $this->assertEquals(100, $lastReportProgress->getProgressFormatted(), 'Last report progress must be set with 100%.');
    }

    /**
     * Run test when GetUserInfo throws exception
     */
    public function testGetUserInfoThrowsException()
    {
        $this->proxy->throwExceptionCode = 400;
        try {
            $this->syncTask->execute();
            $this->fail('Method should throw exception.');
        } catch (HttpRequestException $ex) {
            $accessToken = $this->shopConfig->getAccessToken();
            $this->assertEmpty($accessToken, 'Method should clear access token in configuration service.');
        }
    }

    /**
     * @return RefreshUserInfoTask
     */
    protected function createSyncTaskInstance()
    {
        return new RefreshUserInfoTask('access_token');
    }

    /**
     * @inheritdoc
     */
    protected function initProxy()
    {
        parent::initProxy();
        $dir = realpath(dirname(__FILE__) . '/../..') . '/Common/fakeAPIResponses';
        $this->proxy->setResponse(file_get_contents("$dir/getUserInfo.json"));
    }
}