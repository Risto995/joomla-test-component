<?php

namespace CleverReach\Tests\BusinessLogic\Sync;

abstract class RecipientStatusUpdateSyncTaskTest extends BaseSyncTest
{
    public function testDeactivationSuccess()
    {
        try {
            $this->syncTask->execute();
        } catch (\Exception $ex) {
            $this->fail('Deactivation of recipients should pass successfully.' . $ex->getMessage());
        }
    }

    public function testDeactivationFailure()
    {
        $this->proxy->throwExceptionCode = 400;
        $this->expectException('CleverReach\Infrastructure\Utility\Exceptions\HttpRequestException');
        $this->syncTask->execute();
    }

    protected function getRecipientsEmails()
    {
        $emails = array();
        $numberOfRecipientIdForTest = 20;

        for ($i = 0; $i < $numberOfRecipientIdForTest; $i++) {
            $emails[] = "test$i@test.com";
        }

        return $emails;
    }
}
