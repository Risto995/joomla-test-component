<?php

namespace CleverReach\Tests\BusinessLogic\Sync;

use CleverReach\BusinessLogic\Sync\RecipientDeactivateSyncTask;

class RecipientDeactivateSyncTaskTest extends RecipientStatusUpdateSyncTaskTest
{
    /**
     * @inheritdoc
     */
    protected function createSyncTaskInstance()
    {
        return new RecipientDeactivateSyncTask($this->getRecipientsEmails());
    }
}
