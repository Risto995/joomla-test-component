<?php

namespace CleverReach\Tests\BusinessLogic\Proxy;

use CleverReach\Infrastructure\Utility\HttpResponse;
use CleverReach\Tests\Common\TestComponents\TestProxy;

class ProductSearchTest extends ProxyTestBase
{
    
    /**
     * Test add product search API call when response status is ok
     */
    public function testAddOrUpdateProductSearchOkResponseStatus()
    {
        $fakeJSONResponse = '{
            "id": "16818",
             "name": "My shop - Product search",
             "login": "My shop - Product search",
             "password": "s3Sdsdf34dfsWSW",
             "url": "",
             "interface": "my_products",
             "client_id": "129148",
             "group_id": "0",
             "active": 1,
             "stamp": 1512660984,
             "last_import": 0
        }';
        // Arrange test client and proxy
        $response = new HttpResponse(200, array(), $fakeJSONResponse);
        $this->httpClient->setMockResponses(array($response));

        $proxy = new TestProxy();
        $proxy->setResponse($response);
        $data = json_encode(array(
            'name' => 'My shop - Product search',
            'url' => 'http://myshop.com/endpoint',
            'password' => 's3Sdsdf34dfsWSW',
        ));

        // Act - call method on proxy
        $proxy->addOrUpdateProductSearch($data);

        // Assert if call method is called with appropriate parameters
        $this->assertEquals($proxy->method, 'POST', 'Method for this call must be POST.');
        $this->assertEquals($proxy->endpoint, 'mycontent.json', 'Endpoint for this call must be mycontent.json.');
        $this->assertEquals($proxy->body, $data, 'Body for this call must be set.');
    }

    /**
     * Test add product search API call when response body is not valid
     *
     * @throws \CleverReach\Infrastructure\Utility\Exceptions\HttpRequestException
     */
    public function testAddOrUpdateProductSearchBadResponseBody()
    {
        $response = new HttpResponse(200, array(), 'false');
        $this->httpClient->setMockResponses(array($response));

        $proxy = new TestProxy();
        $proxy->setResponse($response);
        $data = json_encode(array(
            'name' => 'My shop - Product search',
            'url' => 'http://myshop.com/endpoint',
            'password' => 's3Sdsdf34dfsWSW',
        ));

        $this->expectException('CleverReach\Infrastructure\Utility\Exceptions\HttpRequestException');
        $proxy->addOrUpdateProductSearch($data);
    }

    /**
     * Test execute method when product search endpoint already registered
     *
     * @throws \CleverReach\Infrastructure\Utility\Exceptions\HttpRequestException
     */
    public function testAddOrUpdateProductSearchWhenEndpointAlreadySet()
    {
        $response = new HttpResponse(409, array(), '');
        $this->httpClient->setMockResponses(array($response));

        $proxy = new TestProxy();
        $proxy->setResponse($response);
        $data = json_encode(array(
            'name' => 'My shop - Product search',
            'url' => 'http://myshop.com/endpoint',
            'password' => 's3Sdsdf34dfsWSW',
        ));

        $proxy->addOrUpdateProductSearch($data);
        $this->assertEquals('Product search endpoint already exists on CR. If you want to update you need to change name and endpoint url.',
            $this->shopLogger->data->getMessage(), 'Log info message for already created product search endpoint must be set.');
    }

}