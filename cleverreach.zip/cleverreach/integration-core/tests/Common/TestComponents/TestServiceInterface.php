<?php

namespace CleverReach\Tests\Common\TestComponents;

interface TestServiceInterface
{
    const CLASS_NAME = __CLASS__;
}