<?php

namespace CleverReach\Tests\Common\TestComponents;

use CleverReach\BusinessLogic\Entity\ShopAttribute;
use CleverReach\BusinessLogic\Interfaces\Attributes;

class TestAttributes implements Attributes
{

    /**
     * Get attribute from shop with translated description in shop language
     * It should set description, preview_value and default_value based on attribute name
     *
     * @param string $attributeName
     * @return ShopAttribute
     */
    public function getAttributeByName($attributeName)
    {
        $shopAttribute = new ShopAttribute();
        $shopAttribute->setDescription('Description');
        $shopAttribute->setPreviewValue('Preview value');
        $shopAttribute->setDefaultValue('Default value');

        return $shopAttribute;
    }
}