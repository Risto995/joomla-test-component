<?php

namespace CleverReach\Tests\Common\TestComponents\TaskExecution;

class BarTask extends FooTask
{

}