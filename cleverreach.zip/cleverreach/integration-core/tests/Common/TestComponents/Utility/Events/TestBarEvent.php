<?php

namespace CleverReach\Tests\Common\TestComponents\Utility\Events;

use CleverReach\Infrastructure\Utility\Events\Event;

class TestBarEvent extends Event
{
    const CLASS_NAME = __CLASS__;
}