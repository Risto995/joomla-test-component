<?php

namespace CleverReach\Tests\GenericTests;

/**
 * Class GenericTestException
 *
 * @package CleverReach\Tests\GenericTests
 */
class GenericTestException extends \Exception
{
}
